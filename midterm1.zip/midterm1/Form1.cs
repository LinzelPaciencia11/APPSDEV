﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace midterm1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Form2 f2 = new Form2();

        private void button1_Click(object sender, EventArgs e)
        {
            f2.Show();
            char operatorSign = Convert.ToChar(txtBox1.Text);
            double operand = Convert.ToDouble(txtBox2.Text);
            f2.DoNextOperation(operatorSign, operand);
            
        }
    }
}
