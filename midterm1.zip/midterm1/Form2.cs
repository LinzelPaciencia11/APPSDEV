﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace midterm1
{
    public partial class Form2 : Form
    {

        public Form2()
        {
            InitializeComponent();
        }
        char operatorSign;
        double operand;
        double total = 0;
        private void Form2_Load(object sender, EventArgs e)
        {
        }
        public void ScanData(char operatorSign, double operand)
        {
            this.operatorSign = operatorSign;
            this.operand = operand;
        }
        public void DoNextOperation(char operatorSign, double operand)
        {
            switch (operatorSign)
            {
                case '+':
                    total += operand;
                    listBox1.Items.Add(operatorSign + " " + operand);
                    listBox1.Items.Add("The resulrt so far is: " + total.ToString("N1"));
                    break;
                case '-':
                    total -= operand;
                    listBox1.Items.Add(operatorSign + " " + operand);
                    listBox1.Items.Add("The resulrt so far is: " + total.ToString("N1"));
                    break;
                case '*':
                    total *= operand;
                    listBox1.Items.Add(operatorSign + " " + operand);
                    listBox1.Items.Add("The resulrt so far is: " + total.ToString("N1"));
                    break;
                case '/':
                    total /= operand;
                    listBox1.Items.Add(operatorSign + " " + operand);
                    listBox1.Items.Add("The resulrt so far is: " + total.ToString("N1"));
                    break;
                case '^':
                    //for power nga dili ma convert to doublle Math.Pow
                    total = Math.Pow(total, operand);
                    listBox1.Items.Add(operatorSign + " " + operand);
                    listBox1.Items.Add("The result so far is: " + total.ToString("N1"));
                    break;
                // Add cases for other operations as needed
                case 'q':
                    listBox1.Items.Add(operatorSign + " " + operand);
                    listBox1.Items.Add("The FINAL result is: " + total.ToString("N1"));
                    // Perform division operation
                    break;
                    // Add cases for other operations as needed

            }
        }
    }
}
