﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Billiard_Tani
{
    public partial class USERPAGE : Form
    {
        private string login;
        public USERPAGE(string username)
        {
            InitializeComponent();
            login = username;
            LoadUserInfo();
        }
        private void LoadUserInfo()
        {
            try
            {
                Connection.Connection.DB();
                DBHelper.DBHelper.gen = "SELECT fullname, contactNo, address FROM users WHERE [username] = @username";

                using (OleDbCommand command = new OleDbCommand(DBHelper.DBHelper.gen, Connection.Connection.conn))
                {
                    command.Parameters.AddWithValue("@username", login);

                    using (OleDbDataReader reader = command.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            reader.Read();

                            // Displaying retrieved information in the appropriate text boxes
                            txt1.Text = reader["fullname"].ToString();
                            txt2.Text = reader["contactNo"].ToString();
                            txt3.Text = reader["address"].ToString();
                        }
                        else
                        {
                            MessageBox.Show("No data has been found.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void label8_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
    }
}
