﻿namespace Billiard_Tani
{
    partial class USERPAGE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label8 = new System.Windows.Forms.Label();
            this.txt3 = new System.Windows.Forms.TextBox();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Trebuchet MS", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label8.Location = new System.Drawing.Point(704, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(84, 37);
            this.label8.TabIndex = 22;
            this.label8.Text = "BACK";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // txt3
            // 
            this.txt3.ForeColor = System.Drawing.SystemColors.MenuText;
            this.txt3.Location = new System.Drawing.Point(118, 91);
            this.txt3.Name = "txt3";
            this.txt3.Size = new System.Drawing.Size(174, 20);
            this.txt3.TabIndex = 25;
            // 
            // txt2
            // 
            this.txt2.ForeColor = System.Drawing.SystemColors.MenuText;
            this.txt2.Location = new System.Drawing.Point(118, 63);
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(174, 20);
            this.txt2.TabIndex = 24;
            // 
            // txt1
            // 
            this.txt1.ForeColor = System.Drawing.SystemColors.MenuText;
            this.txt1.Location = new System.Drawing.Point(118, 37);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(174, 20);
            this.txt1.TabIndex = 23;
            // 
            // USERPAGE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txt3);
            this.Controls.Add(this.txt2);
            this.Controls.Add(this.txt1);
            this.Controls.Add(this.label8);
            this.Name = "USERPAGE";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "USERPAGE";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt3;
        private System.Windows.Forms.TextBox txt2;
        private System.Windows.Forms.TextBox txt1;
    }
}