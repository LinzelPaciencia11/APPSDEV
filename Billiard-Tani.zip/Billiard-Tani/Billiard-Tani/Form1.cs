﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Billiard_Tani
{
    public partial class Form1 : Form
    {
        private bool isAdmin = true;
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                Connection.Connection.DB();
                DBHelper.DBHelper.gen = "Select * from users where [username] = '" + txtusername.Text + "' and [password] = '" + txtpassword.Text + "'";
                DBHelper.DBHelper.command = new OleDbCommand(DBHelper.DBHelper.gen, Connection.Connection.conn);
                DBHelper.DBHelper.reader = DBHelper.DBHelper.command.ExecuteReader();

                if (DBHelper.DBHelper.reader.HasRows)
                {
                    DBHelper.DBHelper.reader.Read();
                    //database  
                    txtusername.Text = (DBHelper.DBHelper.reader["username"].ToString());
                    txtpassword.Text = (DBHelper.DBHelper.reader["password"].ToString());

                    // Check for admin account
                    if (txtusername.Text == "admin" && txtpassword.Text == "admin")
                    {
                        isAdmin = true;
                    }
                    else
                    {
                        isAdmin = false;
                    }

                    timer1.Enabled = true;
                    timer1.Start();
                    timer1.Interval = 1;
                    progressBar1.Maximum = 200;
                    timer1.Tick += new EventHandler(timer1_Tick);
                }
                else
                {
                    MessageBox.Show("Invalid Username and Password");
                }

                Connection.Connection.conn.Close();
            }
            catch (Exception ex)
            {
                Connection.Connection.conn.Close();
                MessageBox.Show(ex.Message);
            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (progressBar1.Value != 200)
            {
                progressBar1.Value++;
            }
            else
            {
                timer1.Stop();
                progressBar1.Value = 0;

                if (isAdmin)
                {
                    ADMINPAGE admin = new ADMINPAGE();
                    admin.Show();
                }
                else
                {
                    USERPAGE user = new USERPAGE(txtusername.Text);
                    user.Show();
                }

                this.Hide();
            }
        }

        private void Label1_Click_1(object sender, EventArgs e)
        {
            NEWACCOUNT n = new NEWACCOUNT();
            n.Show();
            this.Hide();
        }

        private void txtusername_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
