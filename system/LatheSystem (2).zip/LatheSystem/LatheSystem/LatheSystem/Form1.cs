﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;


namespace LatheSystem
{
    public partial class Form1 : Form
    {
        public static string sendtext = "";
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }


        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Connection.Connection.DB();
                DBHelper.DBHelper.gen = "SELECT * FROM users WHERE [username] = @username AND [password] = @password";
                using (OleDbCommand command = new OleDbCommand(DBHelper.DBHelper.gen, Connection.Connection.conn))
                {
                    command.Parameters.AddWithValue("@username", txtusername.Text);
                    command.Parameters.AddWithValue("@password", txtpassword.Text);
                    using (OleDbDataReader reader = command.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            reader.Read();
                            // Open the next form
                            // Stocks s = new Stocks ();
                            // s.Show();
                            // this.Visible = false; // Closing the login form
                            // sale.Show();
                            timer1.Enabled = true;
                            timer1.Start();
                            timer1.Interval = 1;
                            progressBar1.Maximum = 200;
                            timer1.Tick += new EventHandler(timer1_Tick);
                        }
                        else
                        {
                            MessageBox.Show("Invalid Username and Password");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            if (txtusername.Text == "admin" && txtpassword.Text == "admin")
            {
                // Admin login
                Stocks adminForm = new Stocks();
                adminForm.Show();
                this.Hide(); // Hide the login form
            }
            else if (IsValidUser(txtusername.Text, txtpassword.Text))
            {
                // Regular user login
                UserForm userForm = new UserForm();
                userForm.Show();
                this.Hide(); // Hide the login form
            }
            else
            {
                //MessageBox.Show("Invalid username or password");
            }
        }

        bool IsValidUser(string username, string password)
        {
            string checkUserQuery = "SELECT COUNT(*) FROM Account WHERE [username] = @username AND [password] = @password";
            using (OleDbConnection conn = new OleDbConnection(Connection.Connection.conn.ConnectionString))
            using (OleDbCommand checkCmd = new OleDbCommand(checkUserQuery, conn))
            {
                conn.Open();
                checkCmd.Parameters.AddWithValue("@username", username);
                checkCmd.Parameters.AddWithValue("@password", password);
                int count = (int)checkCmd.ExecuteScalar();
                return count > 0;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (progressBar1.Value != 200)
            {
                progressBar1.Value++;
            }
            else
            {
                timer1.Stop();
                this.Hide();

                progressBar1.Value = 0;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            CreateAccount register = new CreateAccount();
            register.Show();
            this.Hide();
        }
    }
}
