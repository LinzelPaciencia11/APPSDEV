﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1.DBhelper;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public static string sendtext = " ";
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //retrieving username and password from the database
            try
            {
                Connection.user.DB();
                DBhelper.dbhelper.gen = "Select * from users where [username] = '" + txtusername.Text + "' and [password] = '" + txtpassword.Text + "'";
                DBhelper.dbhelper.command = new OleDbCommand(DBhelper.dbhelper.gen, Connection.user.conn);
                DBhelper.dbhelper.reader = DBhelper.dbhelper.command.ExecuteReader();

                if (DBhelper.dbhelper.reader.HasRows)
                {
                    DBhelper.dbhelper.reader.Read();
                    //database  
                    txtusername.Text = (DBhelper.dbhelper.reader["username"].ToString());
                    txtpassword.Text = (DBhelper.dbhelper.reader["password"].ToString());
                    // open a next form  
                    //  Stocks s = new Stocks ();
                    //  s.Show();
                    //   this.Visible =false;//cosing the form
                    //   sale.Show();l

                    timer1.Enabled = true;
                    timer1.Start();
                    timer1.Interval = 1;
                    progressBar1.Maximum = 200;
                    timer1.Tick += new EventHandler(timer1_Tick);


                }
                else
                {
                    MessageBox.Show("Invalid Username and Password");

                }
                Connection.user.conn.Close();
            }
            catch (Exception ex)
            {
                Connection.user.conn.Close();
                MessageBox.Show(ex.Message);

            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (progressBar1.Value != 200)
            {
                progressBar1.Value++;
            }
            else
            {
                timer1.Stop();
                this.Hide();

                progressBar1.Value = 0;
                sendtext = txtusername.Text;
                Form2 s = new Form2();
                s.Show();
            }
        }
    }
    }
