﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace LatheSystem
{

    public partial class UDForm : Form
    {
        public UDForm(string name, string address, string email, string phoneNumber, string nonRu, string ru, string shaft, string rebor, string facing, string machining, string setting, string selectedOrder, string selectedOptions)
        {
            InitializeComponent();

            // Set label1 text to display the data including selected options
            label1.Text = $"Name: {name}\nAddress: {address}\nEmail: {email}\nPhone Number: {phoneNumber}";
            label2.Text = $"Service Request Type:\n{selectedOrder} ";
            label3.Text = $"Selected Services:\n{selectedOptions}";
        }



            private void groupBox1_Enter(object sender, EventArgs e)
            {

            }

            private void UDForm_Load(object sender, EventArgs e)
            {

            }

        private void label4_Click(object sender, EventArgs e)
        {
            UserForm back = new UserForm();
            back.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 back = new Form1();
            back.Show();
            this.Hide();
        }
    }
}
