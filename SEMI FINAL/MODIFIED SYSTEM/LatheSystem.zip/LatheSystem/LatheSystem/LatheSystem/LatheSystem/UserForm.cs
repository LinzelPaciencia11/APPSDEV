﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;
using System.Xml.Linq;
using LatheSystem.DBHelper;

namespace LatheSystem
{

    public partial class UserForm : Form
    {
        public UserForm()
        {
            InitializeComponent();

        }

        private void label1_Click(object sender, EventArgs e)
        {
            Form1 go = new Form1();
            go.Show();
            this.Hide();
        }

        private void UserForm_Load(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = txt1.Text.Trim();
            string address = txt2.Text.Trim();
            string email = txt3.Text.Trim();
            string phoneNumber = txt4.Text.Trim();
            string ru = rbd1.Checked ? rbd1.Text.Trim() : "";
            string nonRu = rbd2.Checked ? rbd2.Text.Trim() : "";
            string shaft = chb1.Checked ? chb1.Text.Trim() : "";
            string rebor = chb2.Checked ? chb2.Text.Trim() : "";
            string facing = chb3.Checked ? chb3.Text.Trim() : "";
            string machining = chb4.Checked ? chb4.Text.Trim() : "";
            string setting = chb5.Checked ? chb5.Text.Trim() : "";

            // Concatenate selected options
            // Concatenate selected options
            string selectedOrder = $"{nonRu}, {ru}";
            string selectedOptions = $"{shaft}, {rebor}, {facing}, {machining}, {setting}";
            selectedOptions = selectedOptions.Replace(", ", "\n");

            // Check if any required field is empty
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(address) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(phoneNumber))
            {
                MessageBox.Show("All fields are required.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                Connection.Connection.DB();

                string insertQuery = "INSERT INTO UserAccount (name, address, email, phoneNumber, nonRu, ru, shaft, rebor, facing, machining, setting) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                OleDbCommand insertCmd = new OleDbCommand(insertQuery, Connection.Connection.conn);
                insertCmd.Parameters.AddWithValue("@name", name);
                insertCmd.Parameters.AddWithValue("@address", address);
                insertCmd.Parameters.AddWithValue("@email", email);
                insertCmd.Parameters.AddWithValue("@phoneNumber", phoneNumber);
                insertCmd.Parameters.AddWithValue("@nonRu", nonRu);
                insertCmd.Parameters.AddWithValue("@ru", ru);
                insertCmd.Parameters.AddWithValue("@shaft", shaft);
                insertCmd.Parameters.AddWithValue("@rebor", rebor);
                insertCmd.Parameters.AddWithValue("@facing", facing);
                insertCmd.Parameters.AddWithValue("@machining", machining);
                insertCmd.Parameters.AddWithValue("@setting", setting);

                int rowsAffected = insertCmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Data saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Pass data to UDForm and show it
                    UDForm udForm = new UDForm(name, address, email, phoneNumber, nonRu, ru, shaft, rebor, facing, machining, setting, selectedOrder, selectedOptions);
                    udForm.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Error creating request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Connection.Connection.conn.Close();
            }

        }

        private void btnUpdate_Click_1(object sender, EventArgs e)
        {
            string name = txt1.Text.Trim();
            string address = txt2.Text.Trim();
            string email = txt3.Text.Trim();
            string phoneNumber = txt4.Text.Trim();
            string ru = rbd1.Checked ? rbd1.Text.Trim() : "";
            string nonRu = rbd2.Checked ? rbd2.Text.Trim() : "";
            string shaft = chb1.Checked ? chb1.Text.Trim() : "";
            string rebor = chb2.Checked ? chb2.Text.Trim() : "";
            string facing = chb3.Checked ? chb3.Text.Trim() : "";
            string machining = chb4.Checked ? chb4.Text.Trim() : "";
            string setting = chb5.Checked ? chb5.Text.Trim() : "";

            string selectedOrder = $"{nonRu}, {ru}";
            string selectedOptions = $"{shaft}, {rebor}, {facing}, {machining}, {setting}";
            selectedOptions = selectedOptions.Replace(", ", "\n");

            // Set values to the text boxes and radio buttons
            txt1.Text = name;
            txt2.Text = address;
            txt3.Text = email;
            txt4.Text = phoneNumber;
            rbd1.Checked = (ru == rbd1.Text.Trim());
            rbd2.Checked = (nonRu == rbd2.Text.Trim());
            chb1.Checked = (shaft == chb1.Text.Trim());
            chb2.Checked = (rebor == chb2.Text.Trim());
            chb3.Checked = (facing == chb3.Text.Trim());
            chb4.Checked = (machining == chb4.Text.Trim());
            chb5.Checked = (setting == chb5.Text.Trim());

            try
            {
                Connection.Connection.DB();

                string updateQuery = "UPDATE UserAccount SET address=?, email=?, phoneNumber=?, nonRu=?, ru=?, shaft=?, rebor=?, facing=?, machining=?, setting=? WHERE name=?";
                OleDbCommand updateCmd = new OleDbCommand(updateQuery, Connection.Connection.conn);
                updateCmd.Parameters.AddWithValue("@address", address);
                updateCmd.Parameters.AddWithValue("@email", email);
                updateCmd.Parameters.AddWithValue("@phoneNumber", phoneNumber);
                updateCmd.Parameters.AddWithValue("@nonRu", nonRu);
                updateCmd.Parameters.AddWithValue("@ru", ru);
                updateCmd.Parameters.AddWithValue("@shaft", shaft);
                updateCmd.Parameters.AddWithValue("@rebor", rebor);
                updateCmd.Parameters.AddWithValue("@facing", facing);
                updateCmd.Parameters.AddWithValue("@machining", machining);
                updateCmd.Parameters.AddWithValue("@setting", setting);
                updateCmd.Parameters.AddWithValue("@name", name);

                int rowsAffected = updateCmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Data saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Pass data to UDForm and show it
                    UDForm udForm = new UDForm(name, address, email, phoneNumber, nonRu, ru, shaft, rebor, facing, machining, setting, selectedOrder, selectedOptions);
                    udForm.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Error creating request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Connection.Connection.conn.Close();
            }

        }

        private void btnDelete_Click_1(object sender, EventArgs e)
        {
            string name = txt1.Text.Trim();

            try
            {
                Connection.Connection.DB();

                string deleteQuery = "DELETE FROM UserAccount WHERE name=?";
                OleDbCommand deleteCmd = new OleDbCommand(deleteQuery, Connection.Connection.conn);
                deleteCmd.Parameters.AddWithValue("@name", name);

                int rowsAffected = deleteCmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Data deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Error deleting data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Connection.Connection.conn.Close();
            }
        }
    }
}

