﻿using LatheSystem.Connection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data;

namespace LatheSystem.DBHelper
{
    class DBHelper
    {
        //used for database transaction
        public static string gen = "";
        public static OleDbConnection conn;
        public static OleDbCommand command;
        public static OleDbDataReader reader;
        public static void UpdateUserAccount(string name, string address, string email, string phoneNumber, string nonRu, string ru, string shaft, string rebor, string facing, string machining, string setting)
        {
            try
            {
                Connection.Connection.DB();

                string updateQuery = "UPDATE UserAccount SET address=?, email=?, phoneNumber=?, nonRu=?, ru=?, shaft=?, rebor=?, facing=?, machining=?, setting=? WHERE name=?";
                OleDbCommand updateCmd = new OleDbCommand(updateQuery, Connection.Connection.conn);
                updateCmd.Parameters.AddWithValue("@address", address);
                updateCmd.Parameters.AddWithValue("@email", email);
                updateCmd.Parameters.AddWithValue("@phoneNumber", phoneNumber);
                updateCmd.Parameters.AddWithValue("@nonRu", nonRu);
                updateCmd.Parameters.AddWithValue("@ru", ru);
                updateCmd.Parameters.AddWithValue("@shaft", shaft);
                updateCmd.Parameters.AddWithValue("@rebor", rebor);
                updateCmd.Parameters.AddWithValue("@facing", facing);
                updateCmd.Parameters.AddWithValue("@machining", machining);
                updateCmd.Parameters.AddWithValue("@setting", setting);
                updateCmd.Parameters.AddWithValue("@name", name);

                int rowsAffected = updateCmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Data updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Error updating data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Connection.Connection.conn.Close();
            }
        }

        public static void DeleteUserAccount(string name)
        {
            try
            {
                Connection.Connection.DB();

                string deleteQuery = "DELETE FROM UserAccount WHERE name=?";
                OleDbCommand deleteCmd = new OleDbCommand(deleteQuery, Connection.Connection.conn);
                deleteCmd.Parameters.AddWithValue("@name", name);

                int rowsAffected = deleteCmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Data deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Error deleting data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Connection.Connection.conn.Close();
            }
        }
    }

}