﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Xml.Linq;

namespace SystemFinal
{
    public partial class UDForm : Form
    {
        private string loggedInUsername;
        public UDForm(string username, string name, string address, string email, string phoneNumber, string nonRu, string ru, string shaft, string rebor, string facing, string machining, string setting, string selectedOrder, string selectedOptions)
        {
            InitializeComponent();

            // Set label1 text to display the data including selected options
            label1.Text = $"Name: {name}\nAddress: {address}\nEmail: {email}\nPhone Number: {phoneNumber}";
            label2.Text = $"Service Request Type:\n{selectedOrder} ";
            label3.Text = $"Selected Services:\n{selectedOptions}";
            loggedInUsername = username;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 back = new Form1();
            back.Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            UserForm back = new UserForm(loggedInUsername);
            back.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
