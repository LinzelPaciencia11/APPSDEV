﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SystemFinal
{
    public partial class UserForm : Form
    {
        private string loggedInUsername;

        public UserForm(string username)
        {
            InitializeComponent();
            loggedInUsername = username;
            LoadUserInfo();
        }

        private void LoadUserInfo()
        {
            try
            {
                Connection.Connection.DB();
                DBHelper.DBHelper.gen = "SELECT name, address, email, phoneNumber FROM Account WHERE [username] = @username";

                using (OleDbCommand command = new OleDbCommand(DBHelper.DBHelper.gen, Connection.Connection.conn))
                {
                    command.Parameters.AddWithValue("@username", loggedInUsername);

                    using (OleDbDataReader reader = command.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            reader.Read();

                            // Displaying retrieved information in the appropriate text boxes
                            txt1.Text = reader["name"].ToString();
                            txt2.Text = reader["address"].ToString();
                            txt3.Text = reader["email"].ToString();
                            txt4.Text = reader["phoneNumber"].ToString();
                        }
                        else
                        {
                            MessageBox.Show("No data found for the logged-in user.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void SaveOrder()
        {
            string orderType = rbd1.Checked ? "Non-Rush Order" : "Rush Order";
            string services = "";
            if (chb1.Checked)
                services += "Shaft, ";
            if (chb2.Checked)
                services += "Rebor, ";
            if (chb3.Checked)
                services += "Facing, ";
            if (chb4.Checked)
                services += "Machining, ";
            if (chb5.Checked)
                services += "Setting, ";
            services = services.TrimEnd(' ', ',');

            try
            {
                Connection.Connection.DB();
                DBHelper.DBHelper.gen = "INSERT INTO [Order] (Username, OrderType, Services) VALUES (@username, @orderType, @services)";

                using (OleDbCommand command = new OleDbCommand(DBHelper.DBHelper.gen, Connection.Connection.conn))
                {
                    command.Parameters.AddWithValue("@username", loggedInUsername);
                    command.Parameters.AddWithValue("@orderType", orderType);
                    command.Parameters.AddWithValue("@services", services);

                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Order saved successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Failed to save order.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            SaveOrder();
            UserTable go = new UserTable();
            go.Show();
            this.Hide();
        }
    }

}
