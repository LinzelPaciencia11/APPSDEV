﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace TestAdmin
{
    public partial class Stocks : Form
    {
        private string sql;
        public Stocks()
        {
            InitializeComponent();
            Message = null;

        }
        public string Message { get; set; }


        private void Stocks_Load(object sender, EventArgs e)
        {
            Label1.Text = Form1.sendtext;
            sql = "Select * from Stock";
            DBHelper.DBHelper.fill(sql, dgvStock);
            GetMaxItemno.GetData.getMaxItem();
            txtItemNo.Text = GetMaxItemno.GlobalDeclaration.itemcode.ToString();

        }


        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                sql = "INSERT INTO Stock(Itemcode, Description, Sprice, Reorderpt, Unit, Expirydate, Datemodified, Stockonhand, Category)" +
                "values(" + txtItemNo.Text + "," +
                 " '" + txtdescription.Text + "'," +
                 " '" + txtsprice.Text + "'," +
                 " " + txtreorderpoint.Text + "," +
                 " '" + txtunit.Text + "'," +
                 " '" + dpexpirydate.Value.Date + "'," +
                 " '" + DateTime.Now.ToShortDateString() + "'," +
                 " " + txtstockonhand.Text + "," +
                 " '" + cbocategory.Text + "')";

                DBHelper.DBHelper.ModifyRecord(sql);
                MessageBox.Show("Data has been added...", "Save new Stock",
               MessageBoxButtons.OK, MessageBoxIcon.Information);
                Stocks_Load(sender, e);
                clearfields();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            sql = "Update Stock SET Description ='" + txtdescription.Text +
             "',Sprice = '" + txtsprice.Text +
             "',Reorderpt = " + txtreorderpoint.Text +
             ",Unit ='" + txtunit.Text +
             "',Expirydate ='" + dpexpirydate.Value.Date +
             "',Datemodified = '" + DateTime.Now.ToShortDateString() +
             "',Stockonhand = " + txtstockonhand.Text +
             ",Category = '" + cbocategory.Text +
             "' where Itemcode = " + txtItemNo.Text + "";
            DBHelper.DBHelper.ModifyRecord(sql);
            MessageBox.Show("Data has been updated...", "Update Stock",
           MessageBoxButtons.OK, MessageBoxIcon.Information);
            Stocks_Load(sender, e);
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            {
                var res = MessageBox.Show("Are you sure you want to delet this record?"
                , "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (res == DialogResult.Yes)
                {
                    sql = "Delete * from Stock where Itemcode =" + txtItemNo.Text + "";
                    DBHelper.DBHelper.ModifyRecord(sql);
                    Stocks_Load(sender, e);
                }
            }

        }
        private void clearfields()
        {
            // txtItemNo.Clear();
            txtdescription.Clear();
            txtsprice.Clear();
            txtreorderpoint.Clear();
            txtunit.Clear();
            dpexpirydate.Text = DateTime.Now.ToShortDateString();
            txtstockonhand.Clear();
            cbocategory.Text = "";
            txtdescription.Select();
        }

        private void dgvStock_CellClick(object sender, DataGridViewCellEventArgs e)
            {
                txtItemNo.Text = dgvStock[0, e.RowIndex].Value.ToString();
                txtdescription.Text = dgvStock[1, e.RowIndex].Value.ToString();
                txtsprice.Text = dgvStock[2, e.RowIndex].Value.ToString();
                txtreorderpoint.Text = dgvStock[3, e.RowIndex].Value.ToString();
                txtunit.Text = dgvStock[4, e.RowIndex].Value.ToString();
                dpexpirydate.Text = dgvStock[5, e.RowIndex].Value.ToString();
                txtstockonhand.Text = dgvStock[7, e.RowIndex].Value.ToString();
                cbocategory.Text = dgvStock[8, e.RowIndex].Value.ToString();

            }

        private void dgvStock_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
