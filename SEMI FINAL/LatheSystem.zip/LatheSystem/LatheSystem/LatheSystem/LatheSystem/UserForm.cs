﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LatheSystem
{
    using System;
    using System.Data;
    using System.Data.OleDb;
    using System.Windows.Forms;

    public partial class UserForm : Form
    {
        public UserForm()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Form1 go = new Form1();
            go.Show();
            this.Hide();
        }

        private void UserForm_Load(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string name = txt1.Text.Trim();
            string address = txt2.Text.Trim();
            string email = txt3.Text.Trim();
            string phoneNumber = txt4.Text.Trim();
            string nonRu = rbd1.Text.Trim();
            string ru = rbd2.Text.Trim();
            string shaft = chb1.Text.Trim();
            string rebor = chb2.Text.Trim();
            string facing = chb3.Text.Trim();
            string machining = chb4.Text.Trim();
            string setting = chb5.Text.Trim();


            // Check if username or password is empty
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(address) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(phoneNumber) || string.IsNullOrEmpty(nonRu) || string.IsNullOrEmpty(ru) || string.IsNullOrEmpty(shaft) || string.IsNullOrEmpty(rebor) || string.IsNullOrEmpty(facing) || string.IsNullOrEmpty(machining) || string.IsNullOrEmpty(setting))
            {
                MessageBox.Show("cannot be empty.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // Exit the method early if validation fails
            }

            try
            {
                Connection.Connection.DB();

                string insertQuery = "INSERT INTO UserAccount (name, address, email, phoneNumber, nonRu, ru, shaft, rebor, facing, machining, setting) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                OleDbCommand insertCmd = new OleDbCommand(insertQuery, Connection.Connection.conn);
                insertCmd.Parameters.AddWithValue("@name", name);
                insertCmd.Parameters.AddWithValue("@address", address);
                insertCmd.Parameters.AddWithValue("@email", email);
                insertCmd.Parameters.AddWithValue("@phoneNumber", phoneNumber);

                insertCmd.Parameters.AddWithValue("@nonRu", nonRu);
                insertCmd.Parameters.AddWithValue("@ru", ru);

                insertCmd.Parameters.AddWithValue("@shaft", shaft);
                insertCmd.Parameters.AddWithValue("@rebor", rebor);
                insertCmd.Parameters.AddWithValue("@facing", facing);
                insertCmd.Parameters.AddWithValue("@machining", machining);
                insertCmd.Parameters.AddWithValue("@setting", setting);


                int rowsAffected = insertCmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Created successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Error creating request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Connection.Connection.conn.Close();
            }
        }
    }
}

