﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Windows.Forms;
namespace LatheSystem.Connection
{
    class Connection
    {
 //used for connection string
        public static OleDbConnection conn;
        private static string dbconnect = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=\"C:\\Users\\1\\Documents\\SEMI FINAL\\LatheSystem\\LatheSystem\\LatheSystem\\LatheSystem\\SystemDatabase.accdb\"";
        public static void DB()
            {
                try
                {
                    conn = new OleDbConnection(dbconnect);
                    conn.Open();
                }
                catch (Exception ex)
                {
                    conn.Close();
                    MessageBox.Show(ex.Message);
                }
           }
    }
}