﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb; //add
using System.Windows.Forms; //add

namespace InventorySystem.Customers
{
    internal class client
    {
        public static OleDbConnection conn;
        private static string dbconnect = " Provider = :Microsoft.ACE.OLEDB.12.0; Data Source = : " + Application.StartupPath + "\\Customers.accdb ";

        public static void DB()
        {
            conn = new OleDbConnection(dbconnect);
            conn.Open();
        }
    }
}