﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace SystemFinal
{
    public partial class UserTable : Form
    {
        private string loggedInUsername;

        public UserTable(string username)
        {
            InitializeComponent();
            loggedInUsername = username;
        }

        private int GetOrderIdToDelete()
        {
            if (dgvOrder.SelectedRows.Count > 0)
            {
                return Convert.ToInt32(dgvOrder.SelectedRows[0].Cells["OrderID"].Value);
            }
            else
            {
                return -1; // Return -1 if no order is selected
            }
        }

        private int GetOrderIdToUpdate()
        {
            if (dgvOrder.SelectedRows.Count > 0)
            {
                return Convert.ToInt32(dgvOrder.SelectedRows[0].Cells["OrderID"].Value);
            }
            else
            {
                return -1; // Return -1 if no order is selected
            }
        }

        private int GetSelectedOrderId()
        {
            if (dgvOrder.SelectedRows.Count > 0)
            {
               return Convert.ToInt32(dgvOrder.SelectedRows[0].Cells["OrderID"].Value);
            }
            else
            {
                return -1; // Return -1 if no order is selected
            }
        }
        private void UserTable_Load(object sender, EventArgs e)
        {
            try
            {
                Connection.Connection.DB();
                DBHelper.DBHelper.gen = "SELECT * FROM [Order] WHERE Username = @username";

                using (OleDbCommand command = new OleDbCommand(DBHelper.DBHelper.gen, Connection.Connection.conn))
                {
                    command.Parameters.AddWithValue("@username", loggedInUsername);

                    OleDbDataAdapter adapter = new OleDbDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dgvOrder.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }

        }

        private void UpdateOrder(int orderId)
        {
            string orderType = rbd1.Checked ? "Rush Order" : "Non-Rush Order";
            string services = "";
            if (chb1.Checked)
                services += "Shafting Motorpump, ";
            if (chb2.Checked)
                services += "Reboring SpraketCopling, ";
            if (chb3.Checked)
                services += "Facing MotorHousing, ";
            if (chb4.Checked)
                services += "Machining Hinges, ";
            if (chb5.Checked)
                services += "Setting GateBalbe, ";
            services = services.TrimEnd(' ', ',');

            try
            {
                Connection.Connection.DB();
                DBHelper.DBHelper.gen = "UPDATE [Order] SET OrderType = @orderType, Services = @services WHERE OrderID = @orderId";

                using (OleDbCommand command = new OleDbCommand(DBHelper.DBHelper.gen, Connection.Connection.conn))
                {
                    command.Parameters.AddWithValue("@orderType", orderType);
                    command.Parameters.AddWithValue("@services", services);
                    command.Parameters.AddWithValue("@orderId", orderId);

                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Order updated successfully.");

                        // Refresh DataGridView after update
                        RefreshDataGridView();
                    }
                    else
                    {
                        MessageBox.Show("Failed to update order.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void RefreshDataGridView()
        {
            try
            {
                Connection.Connection.DB();
                DBHelper.DBHelper.gen = "SELECT * FROM [Order] WHERE Username = @username";

                using (OleDbCommand command = new OleDbCommand(DBHelper.DBHelper.gen, Connection.Connection.conn))
                {
                    command.Parameters.AddWithValue("@username", loggedInUsername);

                    OleDbDataAdapter adapter = new OleDbDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dgvOrder.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error refreshing DataGridView: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnUPDATE_Click(object sender, EventArgs e)
        {
            // Get the OrderID from the TextBox
            if (int.TryParse(textBoxOrderID.Text, out int orderIdToUpdate))
            {
                // Call the UpdateOrder method with the orderIdToUpdate
                UpdateOrder(orderIdToUpdate);
            }
            else
            {
                MessageBox.Show("Please enter a valid OrderID to update.");
            }
        }

        private void DeleteOrder(int orderId)
        {
            try
            {
                Connection.Connection.DB();
                DBHelper.DBHelper.gen = "DELETE FROM [Order] WHERE OrderID = @orderId";

                using (OleDbCommand command = new OleDbCommand(DBHelper.DBHelper.gen, Connection.Connection.conn))
                {
                    command.Parameters.AddWithValue("@orderId", orderId);

                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Order deleted successfully.");

                        // Refresh DataGridView after delete
                        RefreshDataGridView();
                    }
                    else
                    {
                        MessageBox.Show("Failed to delete order.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnDELETE_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBoxOrderID.Text, out int orderIdToDelete))
            {
                // Call the DeleteOrder method with the orderIdToDelete
                DialogResult result = MessageBox.Show("Are you sure you want to delete this order?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    DeleteOrder(orderIdToDelete);
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid OrderID to delete.");
            }
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            UserForm go = new UserForm(loggedInUsername);
            go.Show();
            this.Hide();
        }
    }
}
