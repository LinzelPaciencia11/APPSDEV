﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace SystemFinal
{
    public partial class EditProfile : Form
    {
        private string loggedInUsername;
        public EditProfile(string username)
        {
            InitializeComponent();
            loggedInUsername = username;
            LoadUserInfo();
        }

        private void LoadUserInfo()
        {
            try
            {
                Connection.Connection.DB();
                DBHelper.DBHelper.gen = "SELECT name, address, email, phoneNumber FROM Account WHERE [username] = @username";

                using (OleDbCommand command = new OleDbCommand(DBHelper.DBHelper.gen, Connection.Connection.conn))
                {
                    command.Parameters.AddWithValue("@username", loggedInUsername);

                    using (OleDbDataReader reader = command.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            reader.Read();

                            // Displaying retrieved information in the appropriate text boxes
                            txt1.Text = reader["name"].ToString();
                            txt2.Text = reader["address"].ToString();
                            txt3.Text = reader["email"].ToString();
                            txt4.Text = reader["phoneNumber"].ToString();
                        }
                        else
                        {
                            MessageBox.Show("No data found for the logged-in user.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                Connection.Connection.DB();
                DBHelper.DBHelper.gen = "UPDATE Account SET name = @name, address = @address, email = @email, phoneNumber = @phoneNumber WHERE [username] = @username";

                using (OleDbCommand command = new OleDbCommand(DBHelper.DBHelper.gen, Connection.Connection.conn))
                {
                    command.Parameters.AddWithValue("@name", txt1.Text);
                    command.Parameters.AddWithValue("@address", txt2.Text);
                    command.Parameters.AddWithValue("@email", txt3.Text);
                    command.Parameters.AddWithValue("@phoneNumber", txt4.Text);
                    command.Parameters.AddWithValue("@username", loggedInUsername);

                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Profile updated successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Failed to update profile.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            UserForm go = new UserForm(loggedInUsername);
            go.Show();
            this.Hide();
        }
    }
}
