﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SystemFinal
{
    public partial class Form1 : Form
    {
        public static string sendtext = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Connection.Connection.DB();
                DBHelper.DBHelper.gen = "SELECT * FROM users WHERE [username] = @username AND [password] = @password";
                using (OleDbCommand command = new OleDbCommand(DBHelper.DBHelper.gen, Connection.Connection.conn))
                {
                    command.Parameters.AddWithValue("@username", txtusername.Text);
                    command.Parameters.AddWithValue("@password", txtpassword.Text);
                    using (OleDbDataReader reader = command.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            reader.Read();
                        }
                        else
                        {
                            MessageBox.Show("Invalid Username and Password");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            if (txtusername.Text == "admin" && txtpassword.Text == "admin")
            {
                // Admin login
                Stocks adminForm = new Stocks();
                adminForm.Show();
                this.Hide(); // Hide the login form
            }
            else if (IsValidUser(txtusername.Text, txtpassword.Text))
            {
                UserForm userForm = new UserForm(txtusername.Text);
                userForm.Show();
                this.Hide();
            }

            else
            {
                //MessageBox.Show("Invalid username or password");
            }
        }
        bool IsValidUser(string username, string password)
        {
            string checkUserQuery = "SELECT COUNT(*) FROM Account WHERE [username] = @username AND [password] = @password";
            using (OleDbConnection conn = new OleDbConnection(Connection.Connection.conn.ConnectionString))
            using (OleDbCommand checkCmd = new OleDbCommand(checkUserQuery, conn))
            {
                conn.Open();
                checkCmd.Parameters.AddWithValue("@username", username);
                checkCmd.Parameters.AddWithValue("@password", password);
                int count = (int)checkCmd.ExecuteScalar();
                return count > 0;
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            CreateAccount register = new CreateAccount();
            register.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (txtpassword.PasswordChar == '*')
            {
                button4.BringToFront();
                txtpassword.PasswordChar = '\0';
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (txtpassword.PasswordChar == '\0')
            {
                button3.BringToFront();
                txtpassword.PasswordChar = '*';
            }
        }
    }
}
