﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SYSARCH_proj
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            /*
            if (string.IsNullOrWhiteSpace(txtDeptID.Text))
            {
                MessageBox.Show("Please select a department to update.", "Update Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtDeptName.Text) || string.IsNullOrWhiteSpace(txtDeptCode.Text) || string.IsNullOrWhiteSpace(txtCollegeID.Text))
            {
                MessageBox.Show("All fields are required.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            MySqlConnection conn = new MySqlConnection(connectionString);
                try
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand("UPDATE Department SET CollegeID=@CollegeID, DepartmentName=@DeptName, DepartmentCode=@DeptCode, IsActive=@IsActive WHERE DepartmentID=@DeptID", conn);
                    cmd.Parameters.AddWithValue("@CollegeID", txtCollegeID.Text);
                    cmd.Parameters.AddWithValue("@DeptName", txtDeptName.Text);
                    cmd.Parameters.AddWithValue("@DeptCode", txtDeptCode.Text);
                    cmd.Parameters.AddWithValue("@IsActive", chkIsActive.Checked ? 1 : 0);
                    cmd.Parameters.AddWithValue("@DeptID", txtDeptID.Text);

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Department updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadDepartments();
                    }
                    else
                    {
                        MessageBox.Show("Update failed. Please check your input.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }*/
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            /*
            MySqlConnection conn = new MySqlConnection(connectionString);
                conn.Open();
                MySqlCommand cmd = new MySqlCommand("INSERT INTO Department (CollegeID, DepartmentName, DepartmentCode, IsActive) VALUES (@CollegeID, @DeptName, @DeptCode, @IsActive)", conn);
                cmd.Parameters.AddWithValue("@CollegeID", txtCollegeID.Text);
                cmd.Parameters.AddWithValue("@DeptName", txtDeptName.Text);
                cmd.Parameters.AddWithValue("@DeptCode", txtDeptCode.Text);
                cmd.Parameters.AddWithValue("@IsActive", chkIsActive.Checked ? 1 : 0);
                cmd.ExecuteNonQuery();
            LoadDepartments();
            */
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            /*
                MySqlConnection conn = new MySqlConnection(connectionString);
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand("UPDATE Department SET IsActive = 0 WHERE DepartmentID = @DeptID", conn);
                    cmd.Parameters.AddWithValue("@DeptID", txtDeptID.Text);
                    cmd.ExecuteNonQuery();
                LoadDepartments();
            */
        }
    }
}
