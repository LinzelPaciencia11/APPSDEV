﻿using System;
using System.Data;
using System.Data.SqlClient;
//using MySql.Data.MySqlClient;


namespace SYSARCH_proj
{
    internal class DbHelper
    { /*
        private readonly string connectionString = "server=localhost;database=UniversityDB;user=root;password=yourpassword;";

        public DataTable GetDepartments()
        {
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand("SELECT * FROM Department", conn);
                MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                return dt;
            }
        }*/
    }
}
