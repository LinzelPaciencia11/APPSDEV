﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace act3_wf
{
    using System;
    using System.Drawing;
    using System.IO; // Added to use Path and File classes
    using System.Windows.Forms;

    public partial class Form3 : Form
    {
        private char[] guessedWord;
        private string wordToGuess;
        private int attemptsLeft;
        private Image[] hangmanImages;

        public Form3(string word)
        {
            InitializeComponent();
            LoadHangmanImages();
            wordToGuess = word.ToLower(); // Store the word to guess
            guessedWord = new char[wordToGuess.Length];
            attemptsLeft = 6;

            // Initialize guessedWord array with '*'
            for (int i = 0; i < guessedWord.Length; i++)
            {
                guessedWord[i] = '*';
            }
            UpdateUI();
        }

        private void LoadHangmanImages()
        {
            hangmanImages = new Image[6];
            for (int i = 0; i < 6; i++)
            {
                string imagePath = Path.Combine(Application.StartupPath, $"h{i + 1}.jpg");

                // Check if file exists before loading
                if (File.Exists(imagePath))
                {
                    hangmanImages[i] = Image.FromFile(imagePath);
                }
                else
                {
                    // Handle missing image (e.g., display default image, log error)
                    MessageBox.Show($"Image not found: {imagePath}");
                    // Consider assigning a default image here:
                    // hangmanImages[i] = Properties.Resources.default_hangman_image;

                }
            }
        }

        private void UpdateUI()
        {
            label3.Text = "Attempts left: " + attemptsLeft;
            label4.Text = "Word to guess: " + new string(guessedWord);
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (attemptsLeft <= 0)
            {
                MessageBox.Show("Game over! You lost. The word was: " + wordToGuess);
                return;
            }

            char guessedLetter = textBox1.Text.ToLower()[0];

            bool correctGuess = false;

            for (int i = 0; i < wordToGuess.Length; i++)
            {
                if (wordToGuess[i] == guessedLetter)
                {
                    guessedWord[i] = guessedLetter;
                    correctGuess = true;
                }
            }

            if (correctGuess)
            {
                if (new string(guessedWord) == wordToGuess)
                {
                    MessageBox.Show("Congratulations! You won. The word was: " + wordToGuess);
                    return;
                }
            }
            else
            {
                attemptsLeft--; // Decrease attempts left
                if (attemptsLeft >= 0 && attemptsLeft < hangmanImages.Length) // Check attempts left against the length of hangmanImages
                {
                    pictureBox1.Image = hangmanImages[6 - attemptsLeft - 1]; // Use 6 - attemptsLeft as the index to display images in the correct order
                }
            }

            UpdateUI();
        }
  



        private void button2_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
        }
    }
}



