﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace act3_wf
{
    public partial class Form3 : Form
    {
        private char[] guessedWord;
        private string wordToGuess;
        private int attemptsLeft;

        public Form3(string word)
        {
            InitializeComponent();
            wordToGuess = word.ToLower(); // Store the word to guess
            guessedWord = new char[wordToGuess.Length];
            attemptsLeft = 6;

            // Initialize guessedWord array with '*'
            for (int i = 0; i < guessedWord.Length; i++)
            {
                guessedWord[i] = '*';
            }
            UpdateUI();
        }

        private void UpdateUI()
        {
            label3.Text = "Attempts left: " + attemptsLeft;
            label4.Text = "Word to guess: " + new string(guessedWord);
        }



        private void button1_Click_1(object sender, EventArgs e)
        {
            if (attemptsLeft <= 0)
            {
                MessageBox.Show("Game over! You lost. The word was: " + wordToGuess);
                return;
            }

            char guessedLetter = textBox1.Text.ToLower()[0];

            bool correctGuess = false;

            for (int i = 0; i < wordToGuess.Length; i++)
            {
                if (wordToGuess[i] == guessedLetter)
                {
                    guessedWord[i] = guessedLetter;
                    correctGuess = true;
                }
            }

            if (correctGuess)
            {
                if (new string(guessedWord) == wordToGuess)
                {
                    MessageBox.Show("Congratulations! You won. The word was: " + wordToGuess);
                    return;
                }
            }
            else
            {
                attemptsLeft--;
                //MessageBox.Show("Incorrect guess! Attempts left: " + attemptsLeft);
            }

            UpdateUI();
        }

    }
}



