﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace act3_wf
{
    public partial class Form1 : Form
    {
        private Form2 form2;

        public Form1()
        {
            InitializeComponent();
            form2 = new Form2();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            form2.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            // string storedWord = form2.GetStoredWord();
            // Form3 form3 = new Form3();
            // form3.Show(storedWord);
            string storedWord = form2.GetStoredWord();
            Form3 form3 = new Form3(storedWord);
            form3.Show();
            this.Hide();
        }
    }

}
