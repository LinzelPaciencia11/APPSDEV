﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace act3_wf
{
    public partial class Form2 : Form
    {
        private string storedWord;

        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            storedWord = textBox1.Text;
           
        }

        public string GetStoredWord()
        {
            return storedWord;
        }
    }

}
