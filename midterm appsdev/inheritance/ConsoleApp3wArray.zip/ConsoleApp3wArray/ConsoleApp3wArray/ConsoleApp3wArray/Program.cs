﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[,] details = new string[3, 7];
            WorkExperience[] workExperiences = new WorkExperience[3];

            for (int i = 0; i < details.GetLength(0); i++)
            {
                Console.WriteLine("PERSON " + (i + 1));
                Console.Write("First name: ");
                details[i, 0] = Console.ReadLine();
                Console.Write("Last name: ");
                details[i, 1] = Console.ReadLine();

                Console.Write("Age: ");
                details[i, 2] = Console.ReadLine();

                Console.Write("Course: ");
                details[i, 3] = Console.ReadLine();

                Console.Write("Year Level: ");
                details[i, 4] = Console.ReadLine();

                Console.Write("Work Experience: ");
                details[i, 5] = Console.ReadLine();

                Console.Write("No. of Experiences: ");
                details[i, 6] = Console.ReadLine();

                string firstname = details[i, 0];
                string lastname = details[i, 1];
                int age = int.Parse(details[i, 2]);
                string coursedesc = details[i, 3];
                int yearlevel = int.Parse(details[i, 4]);
                string workdesc = details[i, 5];
                int noofexperience = int.Parse(details[i, 6]);

                workExperiences[i] = new WorkExperience(firstname, lastname, age, coursedesc, yearlevel, workdesc, noofexperience);
            }
            int choice;
            do
            {
                Console.WriteLine("\nMenu:");
                Console.WriteLine("1. Sort (ascending)");
                Console.WriteLine("2. Sort (descending)");
                Console.WriteLine("3. Search");
                Console.WriteLine("4. End program");
                Console.Write("Enter your choice: ");
                choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Array.Sort(workExperiences, CompareAscendingLastName);
                        PrintWorkExperiences(workExperiences);
                        break;
                    case 2:
                        Array.Sort(workExperiences, CompareDescendingLastName);
                        PrintWorkExperiences(workExperiences);
                        break;
                    case 3:
                        Console.WriteLine("Enter name to search: ");
                        string searchName = Console.ReadLine();
                        Search(workExperiences, searchName);
                        break;
                    case 4:
                        Console.WriteLine("Exiting program...");
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            } while (choice != 4);

            Console.ReadKey();
        }
        static int CompareAscendingLastName(WorkExperience x, WorkExperience y)
        {
            return string.Compare(x.Getlastname(), y.Getlastname(), StringComparison.OrdinalIgnoreCase);
        }

        static int CompareDescendingLastName(WorkExperience x, WorkExperience y)
        {
            return string.Compare(y.Getlastname(), x.Getlastname(), StringComparison.OrdinalIgnoreCase);
        }

        static void Search(WorkExperience[] workExperiences, string name)
        {
            bool found = false;
            foreach (var experience in workExperiences)
            {
                if (experience.Getfirstname().Equals(name, StringComparison.OrdinalIgnoreCase) ||
                  experience.Getlastname().Equals(name, StringComparison.OrdinalIgnoreCase))
                {
                    experience.displayinfo();
                    found = true;
                    break;
                }
            }
            if (!found)
            {
                Console.WriteLine("Name not found.");
            }
        }
            static void PrintWorkExperiences(WorkExperience[] workExperiences)
        {
            Console.WriteLine("\nDisplaying all information:");
            foreach (var experience in workExperiences)
            {
                experience.displayinfo();
            }

        }
    }
}
