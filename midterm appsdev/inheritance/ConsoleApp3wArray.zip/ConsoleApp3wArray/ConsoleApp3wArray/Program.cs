﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[,] details = new string[3, 7];
            WorkExperience[] workExperiences = new WorkExperience[3];

            for (int i = 0; i < details.GetLength(0); i++)
            {
                Console.WriteLine("PERSON " + (i + 1));
                Console.WriteLine("First name: ");
                details[i, 0] = Console.ReadLine();
                Console.WriteLine("Last name: ");
                details[i, 1] = Console.ReadLine();

                Console.Write("Age: ");
                details[i, 2] = Console.ReadLine();

                Console.Write("Course: ");
                details[i, 3] = Console.ReadLine();

                Console.Write("Year Level: ");
                details[i, 4] = Console.ReadLine();

                Console.Write("Work Experience: ");
                details[i, 5] = Console.ReadLine();

                Console.Write("No. of Experiences: ");
                details[i, 6] = Console.ReadLine();

                string firstname = details[i, 0];
                string lastname = details[i, 1];
                int age = int.Parse(details[i, 2]);
                string coursedesc = details[i, 3];
                int yearlevel = int.Parse(details[i, 4]);
                string workdesc = details[i, 5];
                int noofexperience = int.Parse(details[i, 6]);

                workExperiences[i] = new WorkExperience(firstname, lastname, age, coursedesc, yearlevel, workdesc, noofexperience);
            }

            Console.WriteLine("Displaying all information:");
            for (int i = 0; i < 3; i++)
            {
                workExperiences[i].displayinfo();
            }

            Console.WriteLine("Search by name:");
            string searchName = Console.ReadLine();
            Search(workExperiences, searchName);

            Console.ReadKey();
        }

        static void Search(WorkExperience[] workExperiences, string name)
        {
            bool found = false;
            foreach (var experience in workExperiences)
            {
                if (experience.Getfirstname().Equals(name, StringComparison.OrdinalIgnoreCase) ||
                    experience.Getlastname().Equals(name, StringComparison.OrdinalIgnoreCase))
                {
                    experience.displayinfo();
                    found = true;
                    break;
                }
            }
            if (!found)
            {
                Console.WriteLine("Name not found.");
            }
        }

    }
}
