﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Name: ");
            string firstname = Console.ReadLine();
            string lastname = Console.ReadLine();

            Console.WriteLine("Age: ");
            int age = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Course: ");
            string coursedesc = Console.ReadLine();

            Console.WriteLine("Year Level: ");
            int yearlevel = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Work Experience: ");
            string workdesc = Console.ReadLine();

            Console.WriteLine("No. of Experiences: ");
            int noofexperience = Convert.ToInt32(Console.ReadLine());

            WorkExperience dis = new WorkExperience(firstname, lastname, age, coursedesc, yearlevel, workdesc, noofexperience);
            dis.displayinfo();
            Console.ReadKey();
        }

    }
}
