﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class WorkExperience : Course
    {
        private string workdesc;
        private int noofexperience;

        public WorkExperience(string firstname, string lastname, int age, string coursedesc, int yearlevel, string workdesc, int noofexperience) : base(firstname, lastname, age, coursedesc, yearlevel)
        {
            this.workdesc = workdesc;
            this.noofexperience = noofexperience;
        }
        public string Getworkdesc()
        {
            return this.workdesc;
        }
        public int Getoofexperience()
        {
            return this.noofexperience;
        }
        public override void displayinfo()
        {
            Console.WriteLine("Name: " + Getfirstname() + " " + Getlastname());
            Console.WriteLine("Age: " + Getage());
            Console.WriteLine("Course: " + Getcoursedesc());
            Console.WriteLine("Yr level: " + Getyearlevel());
            Console.WriteLine("Work experience: " + Getworkdesc());
            Console.WriteLine("No. of experiences: " + Getoofexperience());
        }
    }
}
