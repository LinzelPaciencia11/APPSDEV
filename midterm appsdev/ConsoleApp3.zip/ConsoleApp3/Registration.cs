﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Registration
    {
        private string firstname, lastname;
        private int age;
     
        public Registration(string firstname, string lastname, int age)
        {
            this.firstname = firstname;
            this.lastname = lastname;
            this.age = age;
        }

        public string Getfirstname()
        {
            return this.firstname;
        }
        public string Getlastname() 
        {
            return this.lastname;
        }
        public int Getage()
        {
            return this.age;
        }
        public virtual void displayinfo()
        {
            Console.Write("Name: ");
            firstname = Console.ReadLine();
            lastname = Console.ReadLine();
            Console.WriteLine(" ");
            Console.Write("Age: ");
            age = Convert.ToInt32(Console.ReadLine());
        }
    }
}
