﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace olympics
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[] num = Form2.GetInputScores();

            double[] sortedScores = Form2.SortAndRemoveExtremes(num);


            double total = Form2.CalculateTotal(sortedScores);
            Console.WriteLine("\nThe contestant recieves a total of : " + total.ToString("N2") + " points.");
            Console.ReadKey();

        }
    }
}
