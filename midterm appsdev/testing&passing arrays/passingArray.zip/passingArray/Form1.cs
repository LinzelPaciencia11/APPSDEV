﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace passingArray
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] count = new int[2];
            string[] a = richTextBox1.Lines;
            for (int i = 0; i < 2; i++)
            {
                count[i] = Convert.ToInt32(a[i]);
            }
            //int[] a = { 1, 2 };
            label2.Text = "Before invoking swap                                array is {" + count[0] + ", " + count[1] + "}";

            swap(count[0], count[1]);
            label3.Text = "After invoking swap                                 array is {" + count[0] + ", " + count[1] + "}";

            // Swap elements using the swapFirstTwoInArray method
            label4.Text = "Before invoking swapFirstTwoInArray             array is {" + a[0] + ", " + a[1] + "}";
            swapFirstTwoInArray(count);
            label5.Text = "After invoking swapFirstTwoInArray              array is {" + count[0] + ", " + count[1] + "}";
        }
        /** Swap two variables */
        public static void swap(int n1,int n2)
        {
            int temp = n1;
            n1 = n2;
            n2 = temp;
        }
        /** Swap the first two elements in the array */
        public static void swapFirstTwoInArray(int[] array)
        {
            int temp = array[0];
            array[0] = array[1];
            array[1] = temp;
        }

    }
}
