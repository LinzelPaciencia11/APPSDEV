﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestingArray
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            const int TOTAL_NUMBERS = 6;
            int[] numbers = new int[TOTAL_NUMBERS];
            string[] num = richTextBox1.Lines;

            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = Convert.ToInt32(num[i]);
            }
            //min
            int min = numbers[0];
            for (int i = 1; i < numbers.Length; i++)
            {
                if (min > numbers[i])
                    min = numbers[i];
            }
            //occurance
            int count = 0;
            for (int i = 0; i < numbers.Length; i++)
            {
                if (numbers[i] == min) count++;
            }
            //result
            String output = "The array is ";
            for (int i = 0; i < numbers.Length; i++)
            {
                output += numbers[i] + " ";
            }
            output += "\nThe smallest number is " + min;
            output += "\nThe occurrence count of the smalles number "
            + "is " + count;

            label2.Text = output.ToString();
        }
    }
}
