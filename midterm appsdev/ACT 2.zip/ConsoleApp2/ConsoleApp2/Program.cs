﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] num = Class1.GetInputScores();

            double[] sortedScores = Class1.SortAndRemoveExtremes(num);
            double total = Class1.CalculateTotal(sortedScores);
            Console.WriteLine("\nThe contestant recieves a total of " + total.ToString("N2")+" points.");
            Console.ReadKey();

        }
    }
}
