﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Class1
    {
        public static double[] GetInputScores()
        {
            double[] num = new double[8];
            for (int i = 0; i < 8; i++)
            {
                Console.Write("Enter the score of judge [" + (i + 1) + "]: ");
                num[i] = Convert.ToDouble(Console.ReadLine()); //string to double 
            }
            return num;
        }


        public static double[] SortAndRemoveExtremes(double[] num)
        {
            Array.Sort(num);
            double[] sortedScores = new double[6];
            for (int i = 1; i < 7; i++)
            {
                sortedScores[i - 1] = num[i];
            }
            return sortedScores;
        }
        public static double CalculateTotal(double[] scores)
        {
            double total = 0;
            for (int i = 0; i < scores.Length; i++)
            {
                total += scores[i];
            }
            return total;
        }
    }
}
